
class Solution:
    def help_classmates(self, arr,  n):
        ans = [-1] * n
        stk = []
        for  i in range(n):
            while len(stk) and arr[i] <  arr[stk[-1]]:
                ans[stk.pop()] = arr[i]
            stk.append(i)
        return ans